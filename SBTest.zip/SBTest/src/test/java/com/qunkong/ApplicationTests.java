package com.qunkong;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.qunkong.pojo.User;
import com.qunkong.service.IUserService;

@SpringBootTest
class ApplicationTests {

	@Autowired
	private IUserService userService;
	@Test
	void contextLoads() {
		
		System.out.println("测试用例！");
	}

	@Test
	void usetListTest() {
	List<User> user = userService.userList();
	for (User user1 : user) {
		 System.out.println("用户名"+ user1.getName());
	    }
	}
}
