package com.qunkong.service;

import java.util.List;

import com.qunkong.pojo.User;

public interface IUserService {
	List<User> userList();

}
