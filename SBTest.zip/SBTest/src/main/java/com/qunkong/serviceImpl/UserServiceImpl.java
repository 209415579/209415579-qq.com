package com.qunkong.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qunkong.mapper.UserMapper;
import com.qunkong.pojo.User;
import com.qunkong.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private UserMapper userMapper;

	@Override
	public List<User> userList() {
		// TODO Auto-generated method stub
		return userMapper.userList();
	}

}
